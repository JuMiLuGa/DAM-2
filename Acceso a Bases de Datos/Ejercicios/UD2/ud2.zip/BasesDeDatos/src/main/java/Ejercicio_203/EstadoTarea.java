package Ejercicio_203;

public enum EstadoTarea {
    PENDIENTE, EN_PROCESO, COMPLETADA
}
