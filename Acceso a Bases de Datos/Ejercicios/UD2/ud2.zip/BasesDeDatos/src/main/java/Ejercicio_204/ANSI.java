package Ejercicio_204;

public class ANSI {
    public static final String RESET = "\u001B[0m";
    public static final String BLACK = "\u001B[30m";
    public static final String PURPLE = "\u001B[35m";
    public static final String YELLOW_BACKGROUND = "\u001B[43m";
}