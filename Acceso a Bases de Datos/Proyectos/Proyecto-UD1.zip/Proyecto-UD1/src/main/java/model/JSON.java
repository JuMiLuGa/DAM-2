package model;

public class JSON {

}
