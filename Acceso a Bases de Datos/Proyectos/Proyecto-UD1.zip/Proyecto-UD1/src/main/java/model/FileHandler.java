package model;

import java.io.*;

public class FileHandler {
    private File file;

}
