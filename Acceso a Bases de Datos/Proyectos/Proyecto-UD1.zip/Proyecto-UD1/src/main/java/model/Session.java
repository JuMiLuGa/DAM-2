package model;

public class Session {
    private User user;

}
