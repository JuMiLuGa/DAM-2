class Vehiculo {
    private String color;
    private int numRuedas;
    private int cilindrada;
    private int potencia;


    public Vehiculo(String color, int numRuedas, int cilindrada, int potencia) {
        this.color = color;
        this.numRuedas = numRuedas;
        this.cilindrada = cilindrada;
        this.potencia = potencia;
    }

    // Getters y setters (puedes generarlos automáticamente en tu IDE)
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getNumRuedas() {
        return numRuedas;
    }

    public void setNumRuedas(int numRuedas) {
        this.numRuedas = numRuedas;
    }

    public int getCilindrada() {
        return cilindrada;
    }

    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }
}

class Camion extends Vehiculo {
    private int numEjes;

    public Camion(String color, int numRuedas, int numEjes, int cilindrada, int potencia) {
        super(color, numRuedas, cilindrada, potencia);
        this.numEjes = numEjes;
    }

    public int getNumEjes() {
        return numEjes;
    }

    public void setNumEjes(int numEjes) {
        this.numEjes = numEjes;
    }
}

class Motocicleta extends Vehiculo {
    private int numOcupantes;

    public Motocicleta(String color, int cilindrada, int potencia) {
        super(color, 2, cilindrada, potencia);
    }

    public Motocicleta(String color, int cilindrada, int potencia, int numOcupantes) {
        super(color, 2, cilindrada, potencia);
        this.numOcupantes = numOcupantes;
    }

    public int getNumOcupantes() {
        return numOcupantes;
    }

    public void setNumOcupantes(int numOcupantes) {
        this.numOcupantes = numOcupantes;
    }
}

public class PruebaVehiculos {
    public static void main(String[] args) {
        Motocicleta moto1 = new Motocicleta("Rojo", 125, 25);
        Motocicleta moto2 = new Motocicleta("Verde", 125, 25, 2);
        Camion camion1 = new Camion("Azul", 4, 2, 4000, 300);
        Camion camion2 = new Camion("Blanco", 24, 6, 15000, 0);

        moto1.setNumOcupantes(1); // Establece 1 plaza para la primera moto
        System.out.println("Cilindrada de la segunda moto: " + moto2.getCilindrada());

        camion2.setPotencia(800); // Asigna potencia al segundo camión

        // Muestra los valores de todas las propiedades de los vehículos
        System.out.println("Motocicleta 1:");
        System.out.println("Color: " + moto1.getColor());
        System.out.println("Número de ruedas: " + moto1.getNumRuedas());
        System.out.println("Cilindrada: " + moto1.getCilindrada());
        System.out.println("Potencia: " + moto1.getPotencia());
        System.out.println("Número de ocupantes: " + moto1.getNumOcupantes());

        System.out.println("\nMotocicleta 2:");
        System.out.println("Color: " + moto2.getColor());
        System.out.println("Número de ruedas: " + moto2.getNumRuedas());
        System.out.println("Cilindrada: " + moto2.getCilindrada());
        System.out.println("Potencia: " + moto2.getPotencia());
        System.out.println("Número de ocupantes: " + moto2.getNumOcupantes());

        System.out.println("\nCamión 1:");
        System.out.println("Color: " + camion1.getColor());
        System.out.println("Número de ruedas: " + camion1.getNumRuedas());
        System.out.println("Cilindrada: " + camion1.getCilindrada());
        System.out.println("Potencia: " + camion1.getPotencia());
        System.out.println("Número de ejes: " + camion1.getNumEjes());

        System.out.println("\nCamión 2:");
        System.out.println("Color: " + camion2.getColor());
        System.out.println("Número de ruedas: " + camion2.getNumRuedas());
        System.out.println("Cilindrada: " + camion2.getCilindrada());
        System.out.println("Potencia: " + camion2.getPotencia());
        System.out.println("Número de ejes: " + camion2.getNumEjes());
    }
}
