public interface DatosCentroEstudios {
    byte numeroDePisos = 5;
    byte numeroDeAulas = 25;
    byte numeroDeDespachos = 10;
}