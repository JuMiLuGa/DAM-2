public interface CentroEstudios extends DatosCentroEstudios,CalculosCentroEstudios{
}
