package com.example.recyclerviewconcv;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    RecyclerView rv1;
    String[] nomes={"Sr. botaporfora", "Mr. brown", "Sra. escobilla", "Don Papel"};
    int[] pesos={23,34,45,56};
    int[] imanxes={R.drawable.billa, R.drawable.retrete, R.drawable.escobilla, R.drawable.papel};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rv1=findViewById(R.id.rv1);

        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        rv1.setLayoutManager(linearLayoutManager);

        rv1.setAdapter(new AdaptadorCousa());


    }

    private class AdaptadorCousa extends RecyclerView.Adapter<AdaptadorCousa.AdaptadorCousaHolder> {


        @NonNull
        @Override
        public AdaptadorCousaHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new AdaptadorCousaHolder(getLayoutInflater().inflate(R.layout.layout_tarxeta,parent,false));
        }

        @Override
        public void onBindViewHolder(@NonNull AdaptadorCousaHolder holder, int position) {
            holder.imprimir(position);
        }

        @Override
        public int getItemCount() {
            return nomes.length;
        }

        class AdaptadorCousaHolder extends RecyclerView.ViewHolder{
            ImageView iv1;
            TextView tv1, tv2;


            //Creao o IDE automáticamente
            public AdaptadorCousaHolder(@NonNull View itemView) {
                super(itemView);
                iv1=itemView.findViewById(R.id.imageView);
                tv1=itemView.findViewById(R.id.tvnome);
                tv2=itemView.findViewById(R.id.tvpesos);
            }

            public void imprimir(int position) {
                iv1.setImageResource(imanxes[position]);
                tv1.setText(nomes[position]);
                tv2.setText("Pesos: " + pesos[position]);

            }
        }


    }
}