package com.example.fotos;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    ImageView iv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv1=findViewById(R.id.iv1);

    }

    public void tirarFoto(View view){

        camaralauncher.launch(new Intent(MediaStore.ACTION_IMAGE_CAPTURE));


    }

    public void verGaleria(View view){
        Intent intent = new Intent(this,actividade2.class);
        startActivity(intent);

    }


    ActivityResultLauncher<Intent> camaralauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        @Override
        public void onActivityResult(ActivityResult result) {
            if(result.getResultCode()==RESULT_OK) {
                Bundle extras = result.getData().getExtras();
                Bitmap bitmap1 = (Bitmap) extras.get("data");
                iv1.setImageBitmap(bitmap1);

                try {
                    FileOutputStream fos = openFileOutput(crerNomeArquivoJPG(), Context.MODE_PRIVATE);
                    bitmap1.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                    fos.close();
                } catch (Exception e){
                    Log.e("Excepción foto: ", String.valueOf(e));
                }
            }

        }
    });

    private String crerNomeArquivoJPG(){
        String data=new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        return data+".jpg";

    }




}