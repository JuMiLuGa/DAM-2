package com.example.fotos;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.FileInputStream;

public class actividade2 extends AppCompatActivity {

    RecyclerView rv1;
    String []arquivos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actividade2);

        rv1=findViewById(R.id.rv1);
        arquivos=fileList();

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        rv1.setLayoutManager(linearLayoutManager);
        rv1.setAdapter(new AdaptadorFotos());

    }

    private class AdaptadorFotos extends RecyclerView.Adapter<AdaptadorFotosHolder> {


        @NonNull
        @Override
        public AdaptadorFotosHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new AdaptadorFotosHolder(getLayoutInflater().inflate(R.layout.layout_foto, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull AdaptadorFotosHolder holder, int position) {
            holder.imprimir(position);
        }

        @Override
        public int getItemCount() {
            return arquivos.length;
        }
    }

    private class AdaptadorFotosHolder extends RecyclerView.ViewHolder {
        ImageView iv1;
        TextView tv1;

        public AdaptadorFotosHolder(View itemView){
            super(itemView);
            iv1=itemView.findViewById(R.id.ivfoto);
            tv1=itemView.findViewById(R.id.tvfoto);
        }


        public void imprimir(int position) {

            tv1.setText("Nome de arquivo: " + arquivos[position]);
            try{
                FileInputStream fileInputStream=openFileInput(arquivos[position]);
                Bitmap bitmap= BitmapFactory.decodeStream(fileInputStream);
                iv1.setImageBitmap(bitmap);
                fileInputStream.close();

            } catch (Exception e){
                e.printStackTrace();
            }

        }
    }
}