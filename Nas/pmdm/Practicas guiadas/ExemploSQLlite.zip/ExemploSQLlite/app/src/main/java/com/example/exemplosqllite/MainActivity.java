package com.example.exemplosqllite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etMatricula, etModelo, etMarca, etPrezo;
    AdminSQLiteOpenHelper admin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etMatricula=findViewById(R.id.etMatricula);
        etMarca=findViewById(R.id.etMarca);
        etModelo=findViewById(R.id.etModelo);
        etPrezo=findViewById(R.id.etPrezo);

        admin=new AdminSQLiteOpenHelper(this,"bd1", null, 1);

    }

    public void agregar(View view){
        SQLiteDatabase db=admin.getWritableDatabase();

        ContentValues rexistro=new ContentValues();
        rexistro.put("matricula", etMatricula.getText().toString());
        rexistro.put("modelo", etModelo.getText().toString());
        rexistro.put("marca", etMarca.getText().toString());
        rexistro.put("prezo", etPrezo.getText().toString());
        db.insert("vehiculos", null, rexistro);

        etMarca.setText("");
        etMatricula.setText("");
        etModelo.setText("");
        etPrezo.setText("");

        db.close();
        Toast.makeText(this, "Almacenouse o vehiculo", Toast.LENGTH_LONG).show();

    }

    public void consultar(View view) {
        SQLiteDatabase db = admin.getWritableDatabase();

        String matricula = etMatricula.getText().toString();

        Cursor fila = db.rawQuery("SELECT marca, modelo, prezo FROM vehiculos WHERE matricula='" + matricula + "'", null);

        if (fila.moveToFirst()) {
            etMarca.setText(fila.getString(0));
            etModelo.setText(fila.getString(1));
            etPrezo.setText(fila.getString(2));

        } else
            Toast.makeText(this, "Non existe unvehiculo asociado a esta matrícula", Toast.LENGTH_LONG).show();


        db.close();
    }

    public void borrar(View view) {
        SQLiteDatabase db = admin.getWritableDatabase();
        String matricula = etMatricula.getText().toString();

        int cant=db.delete("vehiculos", "matricula='" + matricula + "'", null);

        if(cant==1){
            Toast.makeText(this, "Elinouse o vehiculo", Toast.LENGTH_SHORT).show();
            etMarca.setText("");
            etMatricula.setText("");
            etModelo.setText("");
            etPrezo.setText("");

        }else
            Toast.makeText(this, "Non existe un vehiculo con esa matrícula", Toast.LENGTH_SHORT).show();

        db.close();
    }

    public void modificar(View view) {
        SQLiteDatabase db = admin.getWritableDatabase();
        String matricula = etMatricula.getText().toString();

        ContentValues rexistro=new ContentValues();
        rexistro.put("modelo", etModelo.getText().toString());
        rexistro.put("marca", etMarca.getText().toString());
        rexistro.put("prezo", etPrezo.getText().toString());
        int cant=db.update("vehiculos", rexistro, "matricula='" + matricula + "'", null);

        if(cant==1) {
            Toast.makeText(this, "Modificaronse o s datos", Toast.LENGTH_SHORT).show();
            etMarca.setText("");
            etMatricula.setText("");
            etModelo.setText("");
            etPrezo.setText("");
        }else
            Toast.makeText(this, "Non existe un vehiculo con esa matrícula", Toast.LENGTH_SHORT).show();

        db.close();
    }

}