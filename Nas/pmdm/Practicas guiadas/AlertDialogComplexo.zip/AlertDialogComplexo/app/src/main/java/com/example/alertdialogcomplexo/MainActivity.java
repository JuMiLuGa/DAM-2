package com.example.alertdialogcomplexo;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tv1, tv2, tv3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv1=findViewById(R.id.tv1);
        tv2=findViewById(R.id.tv2);
        tv3=findViewById(R.id.tv3);
    }

    public void seleccionaDia(View v){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setTitle("Selecciona un día");

        String[] dias ={"segunda feira","terza feira","cuarta feira","quinta feira","sexta feira","sábado", "domingo"};

        builder.setItems(dias, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                tv1.setText("Día=" + dias[which]);
            }
        });

        builder.create().show();


    }


    public void seleccionaMes(View view){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        String[] meses={"xaneiro", "febreiro", "marzal", "abril", "maio", "xuño", "xullo", "agosto", "setembro", "outubro", "san Martiño", "decembro"};
        boolean[] cheks=new boolean[12];

        builder.setMultiChoiceItems(meses, cheks, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                String todo="Mes/es = ";
                for(int j=0; j<cheks.length;j++) {
                    if (cheks[j]) {
                        todo = todo + meses[j] + " ";
                    }

                }
                tv2.setText(todo);
            }
        });

        builder.setPositiveButton("Confirmar", null);
        builder.create().show();

    }

    public void seleccionaHora(View v){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setTitle("Selecciona unha hora");
        String[] horas={"8:00", "8:30","9:00", "9:30", "10:00"};
        builder.setSingleChoiceItems(horas, 0, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                tv3.setText("Hora= " + horas[which]);
            }
        });

        builder.setPositiveButton("Confirmar", null);
        builder.create().show();

    }


}