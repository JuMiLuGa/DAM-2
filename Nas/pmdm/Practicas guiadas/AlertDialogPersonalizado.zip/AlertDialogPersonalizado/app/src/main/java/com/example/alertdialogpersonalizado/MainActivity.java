package com.example.alertdialogpersonalizado;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void seleccionaCor(View v) {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);

        builder.setMessage("Selecciona unha cor");

        View selector=getLayoutInflater().inflate(R.layout.selectordialogo, null);
        builder.setView(selector);

        View vistaCor=selector.findViewById(R.id.view);
        SeekBar sb1 = selector.findViewById(R.id.seekBar);
        SeekBar sb2 = selector.findViewById(R.id.seekBar2);
        SeekBar sb3 = selector.findViewById(R.id.seekBar3);
        TextView tv1=selector.findViewById(R.id.tvVermello);
        TextView tv2=selector.findViewById(R.id.tvVerde);
        TextView tv3=selector.findViewById(R.id.tvAzul);

        vistaCor.setBackgroundColor(Color.rgb(sb1.getProgress(),sb2.getProgress(),sb3.getProgress()));

        sb1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                vistaCor.setBackgroundColor(Color.rgb(sb1.getProgress(),sb2.getProgress(),sb3.getProgress()));
                tv1.setText("Vermello="+progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        sb2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                vistaCor.setBackgroundColor(Color.rgb(sb1.getProgress(),sb2.getProgress(),sb3.getProgress()));
                tv2.setText("Verde="+progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        sb3.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                vistaCor.setBackgroundColor(Color.rgb(sb1.getProgress(),sb2.getProgress(),sb3.getProgress()));
                tv3.setText("Azul="+progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        builder.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Button b=findViewById(R.id.button);
                b.setBackgroundColor(Color.rgb(sb1.getProgress(),sb2.getProgress(),sb3.getProgress()));
            }
        });

        builder.create().show();

    }
}