/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller.donations;

import view.donations.donationsJDialog;

/**
 *
 * @author DAM2_Alu10
 */
public class donationsController {

    private final donationsJDialog view;
    
    public donationsController(donationsJDialog view) {
        this.view = view;
    }
    
}
