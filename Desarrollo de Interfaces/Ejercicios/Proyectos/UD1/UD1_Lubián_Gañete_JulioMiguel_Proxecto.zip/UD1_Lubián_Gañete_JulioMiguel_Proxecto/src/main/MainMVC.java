package main;

import view.MainView;
import javax.swing.JFrame;

public class MainMVC {
    public static void main(String[] args) {
        
        MainView mfv = new MainView();
        mfv.setTitle("Main Menu");
        mfv.setVisible(true);
    }
        
        
}
