package controller.booking.info;

import view.booking.info.BookingInfoJDialog;

public class BookingInfoController {

    private BookingInfoJDialog view;
    
    public BookingInfoController(BookingInfoJDialog bid) {
        this.view = view;
    }
    
}
