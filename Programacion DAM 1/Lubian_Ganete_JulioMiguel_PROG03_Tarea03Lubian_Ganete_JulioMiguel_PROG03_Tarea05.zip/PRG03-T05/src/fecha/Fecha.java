package fecha;

public class Fecha {
    public enum EnumMes {
        ENERO, FEBRERO, MARZO, ABRIL, MAYO, JUNIO, JULIO, AGOSTO, SEPTIEMBRE, OCTUBRE, NOVIEMBRE, DICIEMBRE
    }

    private int dia;
    private EnumMes mes;
    private int anio;

    // Primer constructor
    public Fecha(EnumMes mes) {
        this.mes = mes;
        this.dia = 0;
        this.anio = 0;
    }

    // Segundo constructor
    public Fecha(int dia, EnumMes mes, int anio) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }

    // Métodos para acceder y modificar atributos
    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public EnumMes getMes() {
        return mes;
    }

    public void setMes(EnumMes mes) {
        this.mes = mes;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    // Método para verificar si es verano
    public boolean isSummer() {
        return mes.ordinal() >= EnumMes.JUNIO.ordinal() && mes.ordinal() <= EnumMes.AGOSTO.ordinal();
    }

    // Método para obtener la fecha en formato largo
    public String toString() {
        return dia + " de " + mes + " de " + anio;
    }
}