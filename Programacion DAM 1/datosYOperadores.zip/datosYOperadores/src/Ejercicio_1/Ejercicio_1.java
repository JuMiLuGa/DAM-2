package Ejercicio_1;

public class Ejercicio_1 {

    public static void main(String[] args) {
        String nombre = "Ana";
        short edad = 27;
        double salario = 5300.50;
        boolean carnet = true;

        System.out.println(nombre);
        System.out.println(edad);
        System.out.println(salario);
        System.out.println(carnet);
    }

}
