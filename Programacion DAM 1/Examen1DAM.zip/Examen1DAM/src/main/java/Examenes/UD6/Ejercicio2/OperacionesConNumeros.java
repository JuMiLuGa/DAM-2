package Examenes.UD6.Ejercicio2;

import java.util.Scanner;

public class OperacionesConNumeros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese la cantidad de números que desea introducir: ");
        int cantidadNumeros = scanner.nextInt();

        int[] numeros = new int[cantidadNumeros];

        for (int i = 0; i < cantidadNumeros; i++) {
            System.out.print("Ingrese el número #" + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        // Menú principal
        int opcion;
        do {
            System.out.println("\nMenú Principal:");
            System.out.println("1. Suma");
            System.out.println("2. Producto");
            System.out.println("3. Concatenación");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Resultado de la suma: " + calcularSuma(numeros));
                    break;
                case 2:
                    System.out.println("Resultado del producto: " + calcularProducto(numeros));
                    break;
                case 3:
                    System.out.println("Resultado de la concatenación: " + concatenar(numeros));
                    break;
                case 4:
                    System.out.println("Saliendo del programa. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        } while (opcion != 4);

        scanner.close();
    }

    private static int calcularSuma(int[] numeros) {
        int suma = 0;
        for (int i = 0; i < numeros.length; i++) {
            suma += numeros[i];
        }
        return suma;
    }

    private static int calcularProducto(int[] numeros) {
        int producto = 1;
        for (int i = 0; i < numeros.length; i++) {
            producto *= numeros[i];
        }
        return producto;
    }

    private static String concatenar(int[] numeros) {
        StringBuilder resultado = new StringBuilder();
        for (int i = 0; i < numeros.length; i++) {
            resultado.append(numeros[i]);
        }
        return resultado.toString();
    }

}
