package Examenes.UD5.Ejercicio4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class BuscarCadenaEnArchivo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese la ruta del archivo de texto:");
        String filePath = scanner.nextLine();

        System.out.println("Ingrese la cadena que desea buscar:");
        String cadenaBusqueda = scanner.nextLine();

        try {
            int coincidencias = buscarCadenaEnArchivo(filePath, cadenaBusqueda);
            System.out.println("Se encontraron " + coincidencias + " coincidencias de la cadena en el archivo.");
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }

    private static int buscarCadenaEnArchivo(String filePath, String cadenaBusqueda) throws IOException {
        int coincidencias = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String linea;

            while ((linea = br.readLine()) != null) {
                if (linea.contains(cadenaBusqueda)) {
                    coincidencias++;
                }
            }
        }

        return coincidencias;
    }
}
