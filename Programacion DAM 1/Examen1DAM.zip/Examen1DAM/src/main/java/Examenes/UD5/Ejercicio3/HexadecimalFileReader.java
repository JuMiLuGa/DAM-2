package Examenes.UD5.Ejercicio3;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class HexadecimalFileReader {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese la ruta del archivo binario:");
        String filePath = scanner.nextLine();

        try {
            mostrarContenidoHexadecimal(filePath);
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        } finally {
            scanner.close();
        }
    }

    private static void mostrarContenidoHexadecimal(String filePath) throws IOException {
        try (FileInputStream fis = new FileInputStream(filePath)) {
            int byteLeido;
            int contadorBytes = 0;

            System.out.println("Contenido hexadecimal del archivo:");

            while ((byteLeido = fis.read()) != -1) {
                System.out.printf("%02X ", byteLeido);

                contadorBytes++;
                if (contadorBytes % 16 == 0) {
                    System.out.println();
                }
            }

            System.out.println("\n\nTotal de bytes leídos: " + contadorBytes);
        }
    }
}
