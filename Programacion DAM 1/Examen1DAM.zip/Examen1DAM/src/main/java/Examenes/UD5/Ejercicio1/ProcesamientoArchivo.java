package Examenes.UD5.Ejercicio1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ProcesamientoArchivo {

    public static void main(String[] args) {
        String archivoEntrada = "entrada.txt";
        String archivoSalida = "salida.txt";

        try {
            procesarArchivo(archivoEntrada, archivoSalida);
            System.out.println("Proceso completado con éxito.");
        } catch (IOException e) {
            System.err.println("Error durante la operación de archivos: " + e.getMessage());
        }
    }

    private static void procesarArchivo(String archivoEntrada, String archivoSalida) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(archivoEntrada));
             BufferedWriter bw = new BufferedWriter(new FileWriter(archivoSalida))) {

            int sumaTotal = 0;
            int cantidadTotalNumeros = 0;
            int maximoGlobal = Integer.MIN_VALUE;
            int minimoGlobal = Integer.MAX_VALUE;

            String linea;
            while ((linea = br.readLine()) != null) {
                String[] numeros = linea.split(",");
                int sumaLinea = 0;
                int cantidadNumerosLinea = 0;
                int maximoLinea = Integer.MIN_VALUE;
                int minimoLinea = Integer.MAX_VALUE;

                for (String numero : numeros) {
                    int num = Integer.parseInt(numero.trim());
                    sumaLinea += num;
                    cantidadNumerosLinea++;
                    maximoLinea = Math.max(maximoLinea, num);
                    minimoLinea = Math.min(minimoLinea, num);

                    maximoGlobal = Math.max(maximoGlobal, num);
                    minimoGlobal = Math.min(minimoGlobal, num);
                }

                sumaTotal += sumaLinea;
                cantidadTotalNumeros += cantidadNumerosLinea;

                String resultadoLinea = String.format("%d, %d, %d, %d%n", sumaLinea, cantidadNumerosLinea, maximoLinea, minimoLinea);
                bw.write(resultadoLinea);
            }

            String resultadoGlobal = String.format("%n%d, %d, %d, %d", sumaTotal, cantidadTotalNumeros, maximoGlobal, minimoGlobal);
            bw.write(resultadoGlobal);
        }
    }
}
