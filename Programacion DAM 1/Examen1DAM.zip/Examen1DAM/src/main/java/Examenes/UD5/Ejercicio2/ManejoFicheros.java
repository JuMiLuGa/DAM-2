package Examenes.UD5.Ejercicio2;

import java.io.*;
import java.util.Scanner;

public class ManejoFicheros {

    public static void main(String[] args) {
        ManejoFicheros menu = new ManejoFicheros();
        menu.ejecutarMenu();
    }

    public void ejecutarMenu() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            mostrarMenu();
            int opcion = obtenerOpcionUsuario(scanner);

            switch (opcion) {
                case 1:
                    leerFicheroExistente(scanner);
                    break;
                case 2:
                    crearFicheroNuevo(scanner);
                    break;
                case 3:
                    copiarFichero(scanner);
                    break;
                case 4:
                    buscarPalabraEnFichero(scanner);
                    break;
                case 5:
                    salir();
                    scanner.close();
                    return;
                default:
                    System.out.println("Opción no válida. Por favor, elija una opción del 1 al 5.");
            }
        }
    }

    private void mostrarMenu() {
        System.out.println("\n*** Menú Principal ***");
        System.out.println("1. Leer fichero existente");
        System.out.println("2. Crear fichero nuevo");
        System.out.println("3. Copiar fichero en otro");
        System.out.println("4. Buscar una palabra en el fichero");
        System.out.println("5. Salir");
        System.out.print("Seleccione una opción: ");
    }

    private int obtenerOpcionUsuario(Scanner scanner) {
        int opcion = -1;
        try {
            opcion = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return opcion;
    }

    private void leerFicheroExistente(Scanner scanner) {
        System.out.print("Ingrese el nombre del archivo existente: ");
        String nombreArchivo = scanner.nextLine();
        try {
            BufferedReader br = new BufferedReader(new FileReader(nombreArchivo));
            String linea;
            while ((linea = br.readLine()) != null) {
                System.out.println(linea);
            }
            br.close();
        } catch (FileNotFoundException e) {
            System.err.println("Error: Archivo no encontrado.");
        } catch (IOException e) {
            System.err.println("Error durante la lectura del archivo.");
        }
    }

    private void crearFicheroNuevo(Scanner scanner) {
        System.out.print("Ingrese el nombre del nuevo archivo: ");
        String nombreArchivo = scanner.nextLine();
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(nombreArchivo));
            System.out.println("Ingrese el contenido del archivo (Ctrl + D para finalizar):");
            while (scanner.hasNextLine()) {
                bw.write(scanner.nextLine());
                bw.newLine();
            }
            bw.close();
            System.out.println("Archivo creado con éxito.");
        } catch (IOException e) {
            System.err.println("Error durante la escritura del archivo.");
        }
    }

    private void copiarFichero(Scanner scanner) {
        System.out.print("Ingrese el nombre del archivo existente a copiar: ");
        String nombreArchivoExistente = scanner.nextLine();
        System.out.print("Ingrese el nombre del nuevo archivo de destino: ");
        String nombreArchivoNuevo = scanner.nextLine();
        try {
            BufferedReader br = new BufferedReader(new FileReader(nombreArchivoExistente));
            BufferedWriter bw = new BufferedWriter(new FileWriter(nombreArchivoNuevo));

            String linea;
            while ((linea = br.readLine()) != null) {
                bw.write(linea);
                bw.newLine();
            }

            br.close();
            bw.close();
            System.out.println("Archivo copiado con éxito.");
        } catch (FileNotFoundException e) {
            System.err.println("Error: Archivo existente no encontrado.");
        } catch (IOException e) {
            System.err.println("Error durante la lectura/escritura del archivo.");
        }
    }

    private void buscarPalabraEnFichero(Scanner scanner) {
        System.out.print("Ingrese el nombre del archivo existente: ");
        String nombreArchivo = scanner.nextLine();

        System.out.print("Ingrese la palabra a buscar: ");
        String palabraBuscada = scanner.nextLine();

        try {
            BufferedReader br = new BufferedReader(new FileReader(nombreArchivo));
            String linea;
            int numeroLinea = 0;

            while ((linea = br.readLine()) != null) {
                numeroLinea++;
                if (linea.contains(palabraBuscada)) {
                    System.out.println("Palabra encontrada en la línea " + numeroLinea + ": " + linea);
                }
            }

            br.close();
        } catch (FileNotFoundException e) {
            System.err.println("Error: Archivo no encontrado.");
        } catch (IOException e) {
            System.err.println("Error durante la lectura del archivo.");
        }
    }

    private void salir() {
        System.out.println("¡Hasta luego!");
        System.exit(0);
    }
}

