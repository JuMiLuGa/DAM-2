package Examenes.UD4.Ejercicio4;

import java.util.Scanner;

public class SumaDigitos {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese un número: ");
        int numero = scanner.nextInt();

        int suma = 0;
        int temp = numero;

        while (temp != 0) {
            suma += temp % 10;
            temp /= 10;
        }

        System.out.println("La suma de los dígitos de " + numero + " es: " + suma);

        scanner.close();
    }
}
