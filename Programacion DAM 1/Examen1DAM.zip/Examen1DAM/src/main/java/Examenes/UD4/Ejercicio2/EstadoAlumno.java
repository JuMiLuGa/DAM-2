package Examenes.UD4.Ejercicio2;

import java.util.Scanner;

public class EstadoAlumno {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese la primera calificación: ");
        double calificacion1 = scanner.nextDouble();

        System.out.println("Ingrese la segunda calificación: ");
        double calificacion2 = scanner.nextDouble();

        System.out.println("Ingrese la tercera calificación: ");
        double calificacion3 = scanner.nextDouble();

        double promedio = (calificacion1 + calificacion2 + calificacion3) / 3;

        if (promedio >= 4.0) {
            System.out.println("El alumno aprueba el curso con un promedio de " + promedio);
        } else {
            System.out.println("El alumno suspende el curso con un promedio de " + promedio);
        }

        scanner.close();
    }
}
