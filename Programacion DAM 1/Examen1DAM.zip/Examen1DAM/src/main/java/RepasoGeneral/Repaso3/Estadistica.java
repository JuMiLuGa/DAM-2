package RepasoGeneral.Repaso3;

import java.util.Arrays;

class Estadistica {
    public static double calcularMedia(Muestra muestra) {
        int[] numeros = muestra.getNumeros();
        int cantidad = muestra.getCantidad();
        if (cantidad == 0) return 0;
        int sum = 0;
        for (int num : numeros) {
            sum += num;
        }
        return (double) sum / cantidad;
    }

    public static int calcularModa(Muestra muestra) {
        int[] numeros = muestra.getNumeros();
        int cantidad = muestra.getCantidad();
        if (cantidad == 0) return 0;
        Arrays.sort(numeros);

        int moda = numeros[0];
        int maxCount = 1;
        int currentCount = 1;
        int currentNumber = numeros[0];

        for (int i = 1; i < cantidad; i++) {
            if (numeros[i] == currentNumber) {
                currentCount++;
            } else {
                currentNumber = numeros[i];
                currentCount = 1;
            }

            if (currentCount > maxCount) {
                moda = currentNumber;
                maxCount = currentCount;
            }
        }

        return moda;
    }
}