package RepasoGeneral.Repaso1;

public class Main {
    public static void main(String[] args) {
        // Crear objetos de tipo Alumno
        Alumno alumno1 = new Alumno("Juan", "González", "juan@example.com", 20, "123456789");
        Alumno alumno2 = new Alumno("María", "López", 18);

        // Mostrar por consola si un alumno es mayor de edad
        System.out.println("¿El alumno 1 es mayor de edad?: " + alumno1.esMayorEdad());
        System.out.println("¿El alumno 2 es mayor de edad?: " + alumno2.esMayorEdad());

        // Mostrar si los dos objetos son iguales
        System.out.println("¿Los dos objetos de tipo Alumno son iguales?: " + alumno1.equals(alumno2));

        // Mostrar los detalles de los alumnos
        System.out.println("Detalles del alumno 1: " + alumno1.toString());
        System.out.println("Detalles del alumno 2: " + alumno2.toString());
    }
}