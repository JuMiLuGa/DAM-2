package RepasoGeneral.Repaso4;

public class Main {
    public static void main(String[] args) {
        // Crear algunos productos
        Producto[] productos = {
                new Producto("Laptop", 1200),
                new Producto("Teléfono", 800),
                new Producto("Tablet", 500),
                new Producto("Smartwatch", 300)
        };

        // Calcular precio total de los productos
        double precioTotal = Tienda.calcularPrecioTotal(productos);
        System.out.println("Precio total de los productos en inventario: $" + precioTotal);

        // Encontrar el producto más caro
        Producto productoMasCaro = Tienda.encontrarProductoMasCaro(productos);
        System.out.println("Producto más caro: " + productoMasCaro);
    }
}