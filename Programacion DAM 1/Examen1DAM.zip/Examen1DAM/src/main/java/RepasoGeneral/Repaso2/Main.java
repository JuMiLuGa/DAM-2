package RepasoGeneral.Repaso2;

public class Main {
    public static void main(String[] args) {
        // Inicializar el array con 5 alumnos diferentes
        Alumno[] alumnos = new Alumno[5];
        alumnos[0] = new Alumno("Juan", "González", "juan@example.com", 20, "123456789");
        alumnos[1] = new Alumno("María", "López", "maria@example.com", 18, "987654321");
        alumnos[2] = new Alumno("Carlos", "Martínez", "carlos@example.com", 21, "456789123");
        alumnos[3] = new Alumno("Ana", "Pérez", "ana@example.com", 19, "789123456");
        alumnos[4] = new Alumno("Pedro", "Sánchez", "pedro@example.com", 22, "159357486");

        // Encontrar al alumno más joven
        Alumno alumnoMasJoven = encontrarAlumnoMasJoven(alumnos);

        // Mostrar por consola el alumno más joven
        System.out.printf("El alumno más joven es %s %s con %d años.%n",
                alumnoMasJoven.getNombre(), alumnoMasJoven.getApellidos(),
                alumnoMasJoven.getEdad());
    }

    // Método para encontrar al alumno más joven en un array de alumnos
    public static Alumno encontrarAlumnoMasJoven(Alumno[] alumnos) {
        Alumno masJoven = alumnos[0];
        for (int i = 1; i < alumnos.length; i++) {
            if (alumnos[i].getEdad() < masJoven.getEdad()) {
                masJoven = alumnos[i];
            }
        }
        return masJoven;
    }
}
