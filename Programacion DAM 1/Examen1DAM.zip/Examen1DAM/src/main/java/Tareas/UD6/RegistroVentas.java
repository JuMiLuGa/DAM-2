package Tareas.UD6;

import java.util.Scanner;

import java.util.Scanner;

public class RegistroVentas {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario el número de artículos a introducir
        System.out.print("Ingrese el número de artículos a registrar: ");
        int numArticulos = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea pendiente

        // Arrays para almacenar los datos de los productos
        String[] nombres = new String[numArticulos];
        int[] cantidades = new int[numArticulos];
        double[] precios = new double[numArticulos];
        double totalVenta=0;

        // Introducir datos de los productos
        for (int i = 0; i < numArticulos; i++) {
            System.out.println("\nIntroduzca los datos del artículo #" + (i + 1) + ":");
            System.out.print("Nombre del producto: ");
            nombres[i] = scanner.nextLine();
            System.out.print("Cantidad de unidades vendidas: ");
            cantidades[i] = scanner.nextInt();
            System.out.print("Precio por unidad: ");
            precios[i] = scanner.nextDouble();
            scanner.nextLine(); // Consumir el salto de línea pendiente
        }

        // Mostrar resumen de la venta
        System.out.println("\n------------------------------------------------------------------------");
        System.out.println("RESUMEN DE VENTA");
        System.out.println("------------------------------------------------------------------------");
        //System.out.println("Producto             Cantidad         Precio por unidad      Total");
        System.out.printf("%-20s %-15s %-24s %s \n","Producto","Cantidad","Precio por unidad", "Total");
        System.out.println("------------------------------------------------------------------------");
        for (int i = 0; i < numArticulos; i++) {
            System.out.printf("%-20s %-15d $%-23.2f $%.2f \n", nombres[i], cantidades[i], precios[i],
                    cantidades[i]*precios[i]);
            totalVenta+=cantidades[i]*precios[i];
        }
        System.out.println("------------------------------------------------------------------------");
        System.out.printf("Total de la Venta: $%.2f%n", totalVenta);

        scanner.close();
    }
}
