package Tareas.UD6;

/*

Escribe un programa que dibuje en pantalla un tablero de ajedrez.
Además, pedirá la posición de la reina en el tablero y lo mostrará mediante
un icono como por ejemplo ♛.

 */

import java.util.Scanner;

public class TableroAjedrez2 {
    public static void main(String[] args) {
        final char CUADROBLANCO = '\u25A1';
        final char CUADRONEGRO = '\u25A0';
        final char DAMA = '♛';
        Scanner scanner = new Scanner(System.in);
        char[][] tablero = new char[8][8];
        char color;
        String posicion;
        int filaDama;
        int columnaDama;
        for (int fila = 7; fila>=0; fila--) {

            System.out.print(fila + 1 + "\t");
            for (int columna = 0; columna < 8; columna ++) {

                if (((fila + columna) % 2) == 0)
                    color = CUADROBLANCO;
                else
                    color = CUADRONEGRO;

                System.out.print(color + "\t");
                tablero[fila][columna] = color;
            }
            System.out.println();
        }
        System.out.print(" ");
        for (char letra = 'a'; letra <= 'h'; letra ++) {
            System.out.print("\t"+letra);
        }
        System.out.println();
        System.out.println("Dame la posición de la dama: ");
        posicion = scanner.nextLine();
        columnaDama = (int) (posicion.charAt(0) - 'a');
        filaDama = (int) (posicion.charAt(1) - '1');
        tablero[filaDama][columnaDama] = DAMA;

        // calcular posiciones a las que se puede mover la dama
        for (int fila = 7; fila>=0; fila--) {
            System.out.print(fila + 1 + "\t");
            for (int columna = 0; columna < 8; columna ++) {
                System.out.print(tablero[fila][columna] + "\t");
            }
            System.out.println();
        }
        System.out.print(" ");
        for (char letra = 'a'; letra <= 'h'; letra ++) {
            System.out.print("\t" +letra);
        }
        System.out.println();
    }
}
