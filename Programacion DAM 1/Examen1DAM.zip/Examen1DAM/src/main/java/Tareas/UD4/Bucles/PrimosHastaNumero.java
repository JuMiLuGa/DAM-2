package Tareas.UD4.Bucles;

import java.util.Scanner;



public class PrimosHastaNumero {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numero, i, j;
        boolean esPrimo;

        System.out.print("Ingrese un número entero positivo: ");
        numero = scanner.nextInt();

        while (numero <= 0) {
            System.out.print("Ingrese un número entero positivo: ");
            numero = scanner.nextInt();
        }

        if (numero == 1) {
            System.out.println("No hay nºs primos en el rango (0," + numero + "], según la definición matemática actual");
        } else {
            System.out.println("Números primos en el rango (0," + numero + "]:");


            for (i = 2; i <= numero; i++) {
                esPrimo = true;


                for (j = 2; j <= i / 2; j++) {
                    if (i % j == 0) {
                        esPrimo = false;
                        break;
                    }
                }

                if (esPrimo) {
                    System.out.println(i);
                }
            }
        }
    }
}
