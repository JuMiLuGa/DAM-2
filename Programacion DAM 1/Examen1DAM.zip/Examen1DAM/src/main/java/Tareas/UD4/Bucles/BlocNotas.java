package Tareas.UD4.Bucles;

import java.util.Scanner;



public class BlocNotas {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        char caracter;
        String texto;
        int contadorOcurrencias;

        System.out.print("Introduce un carácter: ");
        caracter = scanner.next().charAt(0);

        System.out.println("Escribe lo que quieras (<> para finalizar)");

        contadorOcurrencias = 0;

        do {
            texto = scanner.nextLine();
            contadorOcurrencias += contarOcurrenciasCaracter(texto, caracter);
        } while (!texto.contains("<>"));

        System.out.println("Apariciones de " + caracter + ": " + contadorOcurrencias);
    }

    // Función para contar las ocurrencias de un carácter en un texto
    static int contarOcurrenciasCaracter(String texto, char caracter) {
        int contador = 0;

        for (int i = 0; i < texto.length(); i++) {
            if (texto.charAt(i) == caracter) {
                contador++;
            }
        }

        return contador;
    }
}
