package Tareas.UD4.Bucles;

import java.util.Scanner;

public class TablaMultiplicar {
    public static void main(String[] args) {
        System.out.println("Escribe un nº de 0 a 9:");
        Scanner cin = new Scanner(System.in);

        int n = cin.nextInt();
        if(n<0 || n>9)
            System.out.println("Número no válido");
        else
            for(int i=0; i<=10; i++)
                System.out.println(n + " x " + i + " = " + n*i);
    }
}
