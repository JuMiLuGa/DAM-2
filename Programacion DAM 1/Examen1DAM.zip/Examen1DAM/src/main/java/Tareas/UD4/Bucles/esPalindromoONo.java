package Tareas.UD4.Bucles;

import java.util.Scanner;

public class esPalindromoONo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese una cadena para verificar si es un palíndromo:");
        String cadena = scanner.nextLine();

        // Eliminar tildes
        String cadenaSinTildes = eliminarTildes(cadena);
        // System.out.println(cadenaSinTildes); //comprobamos transformación sin tildes
        // Eliminar espacios y convertir a minúsculas
        String cadenaSinEspacios = eliminarEspacios(cadenaSinTildes);
        //System.out.println(cadenaSinEspacios); //comprobamos transformación sin espacios ni caracteres
        String cadenaMinusculas = convertirAMinusculas(cadenaSinEspacios);
        //System.out.println(cadenaMinusculas); //comprobamos transformacion a min



        // Invertir la cadena
        String cadenaInvertida = invertirCadena(cadenaMinusculas);
        //System.out.println(cadenaInvertida); //comprobamos inversión de cadena

        // Verificar si es palíndromo
        if (cadenaMinusculas.equals(cadenaInvertida)) {
            System.out.println("La cadena es un palíndromo.");
        } else {
            System.out.println("La cadena no es un palíndromo.");
        }
    }

    static String eliminarEspacios(String cadena) {
        // Eliminar espacios y otros caracteres
        return cadena.replaceAll("[^(a-zA-Z)]", "");
    }

    static String convertirAMinusculas(String cadena) {
        // Convertir la cadena a minúsculas
        return cadena.toLowerCase();
    }

    static String eliminarTildes(String cadena) {
        // Eliminar tildes
        final String conTildes = "áéíóúÁÉÍÓÚ";
        final String sinTildes = "aeiouAEIOU";
        String cadenaSin=new String(cadena);

        for(int i=0; i<10; i++) {
            cadenaSin = cadenaSin.replaceAll(""+ conTildes.charAt(i), "" + sinTildes.charAt(i));

        }
        return cadenaSin;
    }

    static String invertirCadena(String cadena) {
        // Invertir la cadena
        StringBuilder cadenaInvertida = new StringBuilder(cadena);
        return cadenaInvertida.reverse().toString();
    }
}


