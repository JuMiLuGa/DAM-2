package Tareas.UD4.Bucles;

import java.util.Scanner;

public class EsPrimoONo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numero, i, contador;

        System.out.print("Ingrese un número entero positivo: ");
        numero = scanner.nextInt();

        while (numero <= 0) {
            System.out.print("Ingrese un número entero positivo: ");
            numero = scanner.nextInt();
        }

        if (numero == 1) {
            System.out.println("El número no es primo (según la definición matemática actual).");
        } else {
            contador = 0;
            for (i = 2; i <= numero / 2; i++) {
                if (numero % i == 0) {
                    contador = contador + 1;
                }
            }

            if (contador == 0) {
                System.out.println("El número es primo.");
            } else {
                System.out.println("El número no es primo.");
            }
        }
    }
}
