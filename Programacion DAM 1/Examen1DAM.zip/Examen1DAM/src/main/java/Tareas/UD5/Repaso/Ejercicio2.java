package Tareas.UD5.Repaso;

import java.io.*;
import java.util.*;

public class Ejercicio2 {

    public static void main(String[] args) {
        // Solicitar la cantidad de números aleatorios y la ruta del archivo
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese la cantidad de números aleatorios que desea generar: ");
        int cantidadNumeros = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer

        System.out.print("Ingrese la ruta del archivo donde se guardarán los números: ");
        String rutaArchivo = scanner.nextLine();

        // Generar números aleatorios y guardarlos en el archivo
        try (DataOutputStream outputStream = new DataOutputStream(new FileOutputStream(rutaArchivo, true))) {
            Random random = new Random();
            for (int i = 0; i < cantidadNumeros; i++) {
                int numero = random.nextInt(101); // Generar números entre 0 y 100
                outputStream.writeInt(numero);
            }
            System.out.println("Números aleatorios generados y guardados en el archivo exitosamente.");
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo: " + e.getMessage());
        }

        // Mostrar los números guardados en el archivo
        try (DataInputStream inputStream = new DataInputStream(new FileInputStream(rutaArchivo))) {
            System.out.println("Números guardados en el archivo:");
            while (inputStream.available() > 0) {
                int numero = inputStream.readInt();
                System.out.println(numero);
            }
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}
