package Tareas.UD5.Repaso;

import javax.swing.JOptionPane;
import java.io.*;
import java.util.Scanner;

public class Ejercicio1 {

    public static void main(String[] args) {
        // Iteratively get vehicle data from user using JOptionPane dialogs
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("datos_vehiculos.txt", true));

            while (true) {
                String matricula = JOptionPane.showInputDialog("Ingrese la matrícula del vehículo:");
                String marca = JOptionPane.showInputDialog("Ingrese la marca del vehículo:");
                String depositoStr = JOptionPane.showInputDialog("Ingrese el tamaño del depósito (en litros):");
                String modelo = JOptionPane.showInputDialog("Ingrese el modelo del vehículo:");

                // Validate deposito input
                double deposito;
                try {
                    deposito = Double.parseDouble(depositoStr);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "El tamaño del depósito debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
                    continue;
                }

                // Write vehicle data to file
                writer.write(matricula + ", " + marca + ", " + deposito + ", " + modelo + "\n");

                int option = JOptionPane.showConfirmDialog(null, "¿Desea ingresar otro vehículo?", "Confirmación", JOptionPane.YES_NO_OPTION);
                if (option == JOptionPane.NO_OPTION) {
                    break;
                }
            }

            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error al escribir en el archivo.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Show vehicle data stored in the file using JOptionPane dialogs
        try {
            String vehicleData = "";
            Scanner scanner = new Scanner(new File("datos_vehiculos.txt"));
            while (scanner.hasNextLine()) {
                vehicleData += scanner.nextLine() + "\n";
            }
            scanner.close();
            JOptionPane.showMessageDialog(null, "Datos de vehículos almacenados:\n" + vehicleData);
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "El archivo de datos de vehículos no se encontró.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
