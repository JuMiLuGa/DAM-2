package Tareas.UD5.Repaso;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Ejercicio3 {

    public static void main(String[] args) {
        File file = new File("src/main/java/Tareas/UD5/Repaso/enteros.txt");

        // Verificar si el archivo existe
        if (!file.exists()) {
            System.out.println("El archivo no existe.");
            return;
        }

        int suma = 0;
        int cantidadNumeros = 0;

        // Leer el archivo y calcular la suma de los números enteros
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                StringTokenizer tokenizer = new StringTokenizer(line, ", ");

                while (tokenizer.hasMoreTokens()) {
                    String token = tokenizer.nextToken();

                    // Validar si el token es un número entero
                    try {
                        int numero = Integer.parseInt(token);
                        suma += numero;
                        cantidadNumeros++;
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }
                }
            }

            System.out.println("Suma de todos los números enteros: " + suma);
            System.out.println("Cantidad total de números leídos: " + cantidadNumeros);
        } catch (FileNotFoundException e) {
            System.err.println("Error: Archivo no encontrado.");
        } catch (Exception e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}

