package Tareas.UD5;

/*

Crea un programa en Java que lea y muestre el contenido de un archivo binario (datos.bin).
Utiliza la clase FileInputStream para la lectura de bytes. Se adjunta un archivo binario para
facilitar la comprobación del correcto funcionamiento del código.

 */

import java.io.FileInputStream;
import java.io.IOException;

public class Tarefa2 {
    public static void main(String[] args) {
        String rutaArchivo = "mem_128.bin";

        try (FileInputStream fileInputStream = new FileInputStream(rutaArchivo)) {
            int byteLeido;
            while ((byteLeido = fileInputStream.read()) != -1) {
           // while ((fileInputStream.read()) != -1) {
                //System.out.println(byteLeido);
                System.out.print((char) byteLeido);
                //System.out.print((char) fileInputStream.read());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

