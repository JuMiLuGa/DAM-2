package Tareas.UD5.Repaso;

import java.io.*;

public class Ejercicio4 {

    public static void main(String[] args) {
        try {
            // Rutas de los archivos de origen y destino proporcionadas por el usuario
            String archivoOrigen1 = "src/main/java/Tareas/UD5/Repaso/archivo1.bin";
            String archivoOrigen2 = "src/main/java/Tareas/UD5/Repaso/archivo2.bin";
            String archivoDestino = "src/main/java/Tareas/UD5/Repaso/archivoDestino.bin";

            // Combinar archivos binarios
            combinarArchivosBinarios(archivoOrigen1, archivoOrigen2, archivoDestino);

            System.out.println("Los archivos binarios se han combinado exitosamente.");
        } catch (IOException e) {
            System.err.println("Error al combinar archivos binarios: " + e.getMessage());
        }
    }

    public static void combinarArchivosBinarios(String archivoOrigen1, String archivoOrigen2, String archivoDestino) throws IOException {
        try (BufferedInputStream inputStream1 = new BufferedInputStream(new FileInputStream(archivoOrigen1));
             BufferedInputStream inputStream2 = new BufferedInputStream(new FileInputStream(archivoOrigen2));
             BufferedOutputStream outputStream = new BufferedOutputStream(new FileOutputStream(archivoDestino))) {

            // Copiar datos del primer archivo de origen al archivo de destino
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream1.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            // Insertar marcador entre archivos
            String separador = "==== Separador entre archivos ====\n";
            outputStream.write(separador.getBytes());

            // Copiar datos del segundo archivo de origen al archivo de destino
            while ((bytesRead = inputStream2.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
        }
    }
}

