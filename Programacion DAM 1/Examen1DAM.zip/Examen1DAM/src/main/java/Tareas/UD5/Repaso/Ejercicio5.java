package Tareas.UD5.Repaso;

import java.io.*;

public class Ejercicio5 {

    public static void main(String[] args) {
        // Prefijo a buscar en las líneas del archivo de texto
        String prefijo = "Ejemplo";

        // Archivo de entrada y salida
        String archivoEntrada = "src/main/java/Tareas/UD5/Repaso/archivoEntrada5.txt.txt";
        String archivoSalida = "src/main/java/Tareas/UD5/Repaso/lineasFiltradas5.txt";

        try {
            // Filtrar líneas del archivo de texto
            filtrarLineas(archivoEntrada, archivoSalida, prefijo);

            System.out.println("Se han filtrado las líneas que comienzan con el prefijo '" + prefijo + "'.");
        } catch (IOException e) {
            System.err.println("Error al filtrar líneas: " + e.getMessage());
        }
    }

    public static void filtrarLineas(String archivoEntrada, String archivoSalida, String prefijo) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(archivoEntrada));
             BufferedWriter writer = new BufferedWriter(new FileWriter(archivoSalida))) {

            String linea;
            while ((linea = reader.readLine()) != null) {
                if (linea.startsWith(prefijo)) {
                    writer.write(linea);
                    writer.newLine();
                }
            }
        }
    }
}
