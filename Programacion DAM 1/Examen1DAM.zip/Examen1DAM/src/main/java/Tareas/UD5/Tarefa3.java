package Tareas.UD5;

/*

Crea un programa en Java que lea el contenido de un archivo de texto (entrada.txt),
filtre las líneas que contienen la palabra "Java" y escriba esas líneas en otro archivo
de texto (salida_filtrada.txt). Utiliza las clases BufferedReader, BufferedWriter y FileWriter.

 */

import java.io.*;

public class Tarefa3 {
    public static void main(String[] args) {
        String rutaEntrada = "src/main/java/Tareas/UD5/entrada3.txt";
        String rutaSalidaFiltrada = "src/main/java/Tareas/UD5/salida_filtrada.txt";

        try (FileReader fileReader = new FileReader(rutaEntrada);
             BufferedReader bufferedReader = new BufferedReader(fileReader);
             FileWriter fileWriter = new FileWriter(rutaSalidaFiltrada);
             BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {

            String linea;
            while ((linea = bufferedReader.readLine()) != null) {
                if (linea.contains("Java")) {
                    bufferedWriter.write(linea);
                    bufferedWriter.newLine();
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
