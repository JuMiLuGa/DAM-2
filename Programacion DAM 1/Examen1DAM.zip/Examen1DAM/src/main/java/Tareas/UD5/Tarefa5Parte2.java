package Tareas.UD5;

/*

Ahora crea una aplicación que lea este fichero de texto carácter a carácter y muestre su contenido por pantalla  sin espacios.
Por ejemplo, si un fichero tiene el siguiente texto , deberá mostrar <defenderlaalegría>.

 */

import java.io.FileReader;
import java.io.IOException;

public class Tarefa5Parte2 {
    public static void main(String[] args) {
        String nombreArchivo = "Benedetti.txt"; // Nombre del archivo
        try {
            FileReader fr = new FileReader(nombreArchivo); // Abre el archivo para leer

            int caracter;
            while ((caracter = fr.read()) != -1) { // Lee cada caracter del archivo
                if (!Character.isWhitespace(caracter)) { // Si el caracter no es un espacio en blanco
                    System.out.print((char) caracter); // Imprime el caracter en pantalla
                }
            }

            fr.close(); // Cierra el lector de archivo
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}
