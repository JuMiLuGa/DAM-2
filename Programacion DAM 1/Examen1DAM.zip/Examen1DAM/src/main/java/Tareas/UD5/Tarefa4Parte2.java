package Tareas.UD5;

/*

Teniendo en cuenta el fichero creado en el ejercicio anterior, reutiliza ahora tu código para añadir más contenido a tu fichero,
por ejemplo, varias frases como las siguientes: “Esto es lo añadido al texto creado”. La nueva frase creada debería estar en una nueva línea.

 */

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Tarefa4Parte2 {
    public static void main(String[] args){
        File fichero;
        try{
            fichero=new File("CrearFichero.txt");
            FileWriter fw=new FileWriter(fichero,true);
            fw.write("\nEsto es lo añadido al texto creado");
            fw.close();
        }catch(IOException e){
            e.printStackTrace();
        }

    }

}
