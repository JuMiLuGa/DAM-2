package Tareas.UD5;

/*

Teniendo en cuenta el fichero creado en el ejercicio anterior, reutiliza ahora tu código para añadir más contenido a tu fichero,
por ejemplo, varias frases como las siguientes: “Esto es lo añadido al texto creado”. La nueva frase creada debería estar en una nueva línea.

 */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Tarefa4Parte2B {
    public static void main(String[] args) throws IOException {
        File archivo = new File("CrearFichero.txt");
        if (!archivo.exists()) {
            archivo.createNewFile();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo, true))) {
            writer.newLine();
            writer.write("Este es el contenido adicional.");
        }

        System.out.println("Archivo creado con texto");
    }
}
