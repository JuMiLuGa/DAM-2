package Examenes.UD4.Ejercicio3;

import java.util.Scanner;

public class RepetirNombre {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese un nombre: ");
        String nombre = scanner.nextLine();

        System.out.println("Ingrese la cantidad de veces a repetir el nombre: ");
        int cantidad = scanner.nextInt();

        for (int i = 0; i < cantidad; i++) {
            System.out.println(nombre);
        }

        scanner.close();
    }
}
