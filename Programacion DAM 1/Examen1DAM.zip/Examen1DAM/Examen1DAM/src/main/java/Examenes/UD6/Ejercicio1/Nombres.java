package Examenes.UD6.Ejercicio1;

import java.util.Scanner;

public class Nombres {
    public static void main(String[] args) {
        String[] nombres = new String[5];

        Scanner scanner = new Scanner(System.in);

        for (int i = 0; i < 5; i++) {
            System.out.print("Ingresa el nombre " + (i + 1) + ": ");
            nombres[i] = scanner.nextLine();
        }

        System.out.println("Nombres con más de 5 caracteres:");
        for (int i = 0; i < nombres.length; i++) {
            if (nombres[i].length() > 5) {
                System.out.println(nombres[i]);
            }
        }
        scanner.close();
    }
}