package Examenes.UD6.Ejercicio4;

import java.util.Scanner;

public class SumaMatricesCuadradas {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el tamaño de las matrices cuadradas (n x n): ");
        int n = scanner.nextInt();

        int[][] matriz1 = new int[n][n];
        int[][] matriz2 = new int[n][n];
        int[][] matrizSuma = new int[n][n];

        System.out.println("Ingrese los elementos de la primera matriz:");
        ingresarElementosMatriz(scanner, matriz1);

        System.out.println("Ingrese los elementos de la segunda matriz:");
        ingresarElementosMatriz(scanner, matriz2);

        calcularSumaMatrices(matriz1, matriz2, matrizSuma);

        System.out.println("\nMatriz 1:");
        imprimirMatriz(matriz1);

        System.out.println("\nMatriz 2:");
        imprimirMatriz(matriz2);

        System.out.println("\nMatriz Suma:");
        imprimirMatriz(matrizSuma);

        scanner.close();
    }

    private static void ingresarElementosMatriz(Scanner scanner, int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("Ingrese el elemento en la posición [" + i + "][" + j + "]: ");
                matriz[i][j] = scanner.nextInt();
            }
        }
    }

    private static void calcularSumaMatrices(int[][] matriz1, int[][] matriz2, int[][] matrizSuma) {
        for (int i = 0; i < matriz1.length; i++) {
            for (int j = 0; j < matriz1[i].length; j++) {
                matrizSuma[i][j] = matriz1[i][j] + matriz2[i][j];
            }
        }
    }

    private static void imprimirMatriz(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
    }
}

