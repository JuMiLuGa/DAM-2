package Examenes.UD6.Ejercicio3;

import java.util.Scanner;

public class EncontrarMayorMenor {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese la cantidad de números: ");
        int cantidadNumeros = scanner.nextInt();

        int[] numeros = new int[cantidadNumeros];

        for (int i = 0; i < cantidadNumeros; i++) {
            System.out.print("Ingrese el número #" + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

        int[] resultado = encontrarMayorMenor(numeros);

        System.out.println("Resultado:");

        for (int i = 0; i < resultado.length; i++) {
            System.out.print(resultado[i] + " ");
        }

        scanner.close();
    }

    private static int[] encontrarMayorMenor(int[] array) {
        int[] resultado = new int[2];
        if (array.length > 0) {
            int mayor = array[0];
            int menor = array[0];

            for (int i = 1; i < array.length; i++) {
                if (array[i] > mayor) {
                    mayor = array[i];
                }
                if (array[i] < menor) {
                    menor = array[i];
                }
            }
            resultado[0] = mayor;
            resultado[1] = menor;
        }

        return resultado;
    }
}
