package Tareas.UD4.Bucles;

import java.util.Scanner;

public class CambiarMayusculasYMinusculasV2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese un texto: ");
        String texto = scanner.nextLine();

        String textoModificado = cambiarMayusculasMinusculas(texto);

        System.out.println("Texto modificado: " + textoModificado);
    }

    private static String cambiarMayusculasMinusculas(String texto) {
        StringBuilder resultado = new StringBuilder();

        for (int i = 0; i < texto.length(); i++) {
            char caracter = texto.charAt(i);

            if (Character.isUpperCase(caracter)) {
                // Convertir mayúscula a minúscula usando operación de nivel de bits
                caracter = (char) (caracter | 32);
            } else if (Character.isLowerCase(caracter)) {
                // Convertir minúscula a mayúscula usando operación de nivel de bits
                caracter = (char) (caracter & ~32);
            }
            // Ignorar caracteres no alfabéticos

            resultado.append(caracter);
        }

        return resultado.toString();
    }
}
