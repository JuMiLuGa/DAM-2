package Tareas.UD4.Bucles;

import java.util.Scanner;

public class CambiarMayusculasYMinusculasV1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Introduce un texto:");
        String texto = scanner.nextLine();
        String textoConvertido = "";

        for (int i = 0; i < texto.length(); i++) {
            char letra = texto.charAt(i);

            int codigoAscii =(int) letra;
            System.out.println(codigoAscii);

            if ((codigoAscii >= 65 && codigoAscii <= 90) || (codigoAscii >= 97 && codigoAscii <= 122)) {
                // Solo aplicamos el cambio a los caracteres alfabéticos (mayúsculas y minúsculas)
                int nuevoCodigoAscii = codigoAscii;

                if (codigoAscii >= 65 && codigoAscii <= 90) {
                    // Convertir mayúscula a minúscula
                    nuevoCodigoAscii += 32; // Agregamos 32 para invertir el bit 6
                } else {
                    // Convertir minúscula a mayúscula
                    nuevoCodigoAscii -= 32; // Restamos 32 para invertir el bit 6
                }

                char caracterConvertido = (char) nuevoCodigoAscii;
                textoConvertido += caracterConvertido;
            } else {
                // Mantenemos los caracteres no alfabéticos sin cambios
                textoConvertido += letra;
            }
        }

        System.out.println("Texto convertido: " + textoConvertido);
    }
}
