package Tareas.UD5;

/*

Crea un programa en Java que copie el contenido de un archivo de texto
(entrada.txt) a otro archivo de texto (salida.txt).Utiliza clases FileReader
 y FileWriter para realizar la lectura y escritura.

 */

import java.io.*;

public class Tarefa1B {
    public static void main(String[] args) {
        String rutaEntrada = "entrada.txt";
        String rutaSalida = "salida.txt";

        try (FileReader fileReader = new FileReader(rutaEntrada);

             FileWriter fileWriter = new FileWriter(rutaSalida,true);
             ) {

            int caracter;
            while ((caracter = fileReader.read()) != -1) {
                fileWriter.write(caracter);
                //System.out.print((char) caracter);
                //System.out.print((char)fileReader.read());
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
