package Tareas.UD4.Repaso;

import java.util.Scanner;

public class EjerciciosRepaso {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("Elija una opción:");
            System.out.println("1. Rebajar precio de producto");
            System.out.println("2. Mostrar números del 1 al 100 con la estructura repetitiva MIENTRAS");
            System.out.println("3. Mostrar números del 1 al 100 con la estructura repetitiva PARA");
            System.out.println("4. Mostrar números pares del 1 al 100");
            System.out.println("5. Calcular el cuadrado de los N primeros números");
            System.out.println("6. Calcular la nota de n alumnos");
            System.out.println("7. Mostrar reloj digital");
            System.out.println("8. Verificar si una frase es un pangrama");
            System.out.println("9. Contar el número de dígitos de un número");
            System.out.println("10. Mostrar los primeros N términos de la serie Fibonacci");
            System.out.println("11. Calcular cantidad de divisores de un número");
            System.out.println("0. Salir");
            System.out.print("Opción: ");
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    rebajarPrecio();
                    break;
                case 2:
                    mostrarConWhile();
                    break;
                case 3:
                    mostrarConFor();
                    break;
                case 4:
                    mostrarPares();
                    break;
                case 5:
                    calcularCuadrados();
                    break;
                case 6:
                    calcularNotas();
                    break;
                case 7:
                    mostrarReloj();
                    break;
                case 8:
                    verificarPangrama();
                    break;
                case 9:
                    contarDigitos();
                    break;
                case 10:
                    mostrarFibonacci();
                    break;
                case 11:
                    calcularDivisores();
                    break;
                case 0:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        } while (opcion != 0);
    }

    public static void rebajarPrecio() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el precio del producto: ");
        double precio = scanner.nextDouble();
        double precioRebajado = precio * 0.85;
        System.out.println("El precio rebajado es: " + precioRebajado);
    }

    public static void mostrarConWhile() {
        int i = 1;
        while (i <= 100) {
            System.out.println(i);
            i++;
        }
    }

    public static void mostrarConFor() {
        for (int i = 1; i <= 100; i++) {
            System.out.println(i);
        }
    }

    public static void mostrarPares() {
        for (int i = 2; i <= 100; i += 2) {
            System.out.println(i);
        }
    }

    public static void calcularCuadrados() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el valor de N: ");
        int n = scanner.nextInt();
        for (int i = 1; i <= n; i++) {
            System.out.println("El cuadrado de " + i + " es: " + (i * i));
        }
    }

    public static void calcularNotas() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el número de alumnos: ");
        int n = scanner.nextInt();
        for (int i = 1; i <= n; i++) {
            System.out.print("Ingrese la nota teórica del alumno " + i + ": ");
            double notaTeorica = scanner.nextDouble();
            System.out.print("Ingrese la nota práctica del alumno " + i + ": ");
            double notaPractica = scanner.nextDouble();
            double notaFinal = (notaTeorica * 0.6) + (notaPractica * 0.4);
            System.out.println("La nota final del alumno " + i + " es: " + notaFinal);
        }
    }

    public static void mostrarReloj() {
        while (true) {
            try {
                Thread.sleep(1000);
                // Obtiene la hora actual
                long millis = System.currentTimeMillis();
                long segundos = millis / 1000 % 60;
                long minutos = millis / (1000 * 60) % 60;
                long horas = millis / (1000 * 60 * 60) % 24;
                System.out.printf("%02d:%02d:%02d%n", horas, minutos, segundos);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public static void verificarPangrama() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese una frase para verificar si es un pangrama:");
        String frase = scanner.nextLine().toLowerCase();
        boolean[] letras = new boolean[26];
        int totalLetras = 0;

        for (int i = 0; i < frase.length(); i++) {
            char c = frase.charAt(i);
            if (c >= 'a' && c <= 'z') {
                if (!letras[c - 'a']) {
                    letras[c - 'a'] = true;
                    totalLetras++;
                }
            }
        }

        if (totalLetras == 26) {
            System.out.println("La frase es un pangrama.");
        } else {
            System.out.println("La frase no es un pangrama.");
        }
    }

    public static void contarDigitos() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un número: ");
        int numero = scanner.nextInt();
        int digitos = String.valueOf(numero).length();
        System.out.println("El número de dígitos es: " + digitos);
    }

    public static void mostrarFibonacci() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el valor de N para la serie Fibonacci: ");
        int n = scanner.nextInt();
        int a = 0, b = 1;
        System.out.print("Los primeros " + n + " términos de la serie Fibonacci son: ");
        for (int i = 1; i <= n; ++i) {
            System.out.print(a + " ");
            int suma = a + b;
            a = b;
            b = suma;
        }
    }

    public static void calcularDivisores() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un número entero: ");
        int numero = scanner.nextInt();
        int count = 0;
        for (int i = 1; i <= numero; ++i) {
            if (numero % i == 0) {
                count++;
            }
        }
        System.out.println("El número " + numero + " tiene " + count + " divisores.");
    }
}
