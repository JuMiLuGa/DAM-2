package Tareas.UD5;

/*

Escribe un programa en Java que lea el contenido de un fichero de texto ya creado previamente y muestre su contenido en pantalla.
Utiliza el fichero .txt que se adjunta en esta tarea que contiene un fragmento del poema de Mario Benedetti - 'Defender la alegría'.

 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Tarefa5Parte1 {
    public static void main(String[] args) {
        String nombreArchivo = "Benedetti.txt"; // Nombre del archivo
        try {
            FileReader fr = new FileReader(nombreArchivo); // Abre el archivo para leer
            BufferedReader br = new BufferedReader(fr); // Crea un lector de buffer para leer líneas

            String linea;
            while ((linea = br.readLine()) != null) { // Lee cada línea del archivo
                System.out.println(linea); // Imprime la línea en pantalla
            }

            br.close(); // Cierra el lector de buffer
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}
