package Tareas.UD4.Bucles;

import java.util.Scanner;

public class SumaMayorMenor {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String valor;
        double suma = 0, mayor = 0, menor = 0;
        boolean primerNumero = true;

        System.out.println("Ingrese valores numéricos (ingrese 00 para finalizar):");

        while (primerNumero) {
            valor = scanner.next();

            if (valor.equals("00")) {
                primerNumero = false;
            } else {
                double numero = Double.parseDouble(valor);
                suma += numero;

                if (numero > mayor) {
                    mayor = numero;
                }

                if (numero < menor) {
                    menor = numero;
                }
            }
        }

        System.out.println("La suma de los valores es: " + suma);
        System.out.println("El mayor valor introducido es: " + mayor);
        System.out.println("El menor valor introducido es: " + menor);
    }
}
