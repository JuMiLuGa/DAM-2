package Tareas.UD5.Repaso;

import java.io.*;

public class Ejercicio6 {

    public static void main(String[] args) {
        // Archivo de entrada y salida
        String archivoEntrada = "src/main/java/Tareas/UD5/Repaso/archivoEntrada6.txt";
        String archivoSalida = "src/main/java/Tareas/UD5/Repaso/6conteoPalabras.txt";

        try {
            // Contar palabras en el archivo de texto y escribir el conteo en otro archivo
            contarPalabras(archivoEntrada, archivoSalida);

            System.out.println("Se ha contado el número de palabras en el archivo y se ha guardado en " + archivoSalida + ".");
        } catch (IOException e) {
            System.err.println("Error al contar palabras: " + e.getMessage());
        }
    }

    public static void contarPalabras(String archivoEntrada, String archivoSalida) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(archivoEntrada));
             BufferedWriter writer = new BufferedWriter(new FileWriter(archivoSalida))) {

            int contadorPalabras = 0;
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] palabras = linea.split("\\s+"); // Dividir la línea en palabras utilizando espacios como delimitadores
                contadorPalabras += palabras.length;
            }

            // Escribir el conteo de palabras en el archivo de salida
            writer.write("Número total de palabras: " + contadorPalabras);
        }
    }
}
