package Tareas.UD5;
/*

Escribe un programa en Java que cree un fichero de texto llamado “CrearFichero.txt”.
Conteniendo el texto “Este es el archivo de texto creado”.

 */

import java.io.FileWriter;
import java.io.IOException;

public class Tarefa4Parte1 {
    public static void main(String[] args){

        String frase="Este es el archivo de texto creado";
        try {
            FileWriter escritura=new FileWriter("CrearFichero.txt",true);
            for (int i=0;i<frase.length();i++){
                escritura.write(frase.charAt(i));
            }
            escritura.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }
}

