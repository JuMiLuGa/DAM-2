package RepasoGeneral.Repaso3;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Muestra muestra = new Muestra();
        muestra.agregarNumero(2);
        muestra.agregarNumero(3);
        muestra.agregarNumero(3);
        muestra.agregarNumero(5);
        muestra.agregarNumero(7);
        muestra.agregarNumero(5);
        muestra.agregarNumero(5);
        muestra.agregarNumero(8);
        muestra.agregarNumero(9);

        System.out.println("Números en la muestra: " + Arrays.toString(muestra.getNumeros()));
        System.out.println("Cantidad de números en la muestra: " + muestra.getCantidad());
        System.out.println("Media: " + Estadistica.calcularMedia(muestra));
        System.out.println("Moda: " + Estadistica.calcularModa(muestra));
    }
}