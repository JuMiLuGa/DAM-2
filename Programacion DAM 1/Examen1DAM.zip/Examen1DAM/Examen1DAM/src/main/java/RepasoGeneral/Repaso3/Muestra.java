package RepasoGeneral.Repaso3;

import java.util.Arrays;

class Muestra {
    private static final int DEFAULT_SIZE = 10;
    private int[] numeros;
    private int cantidad;

    public Muestra() {
        this.numeros = new int[DEFAULT_SIZE];
        this.cantidad = 0;
    }

    public Muestra(int size) {
        this.numeros = new int[size];
        this.cantidad = 0;
    }

    public Muestra(int[] array) {
        this.numeros = array.clone();
        this.cantidad = array.length;
    }

    public void agregarNumero(int numero) {
        if (cantidad < numeros.length) {
            numeros[cantidad++] = numero;
        } else {
            System.out.println("La muestra está llena, no se puede agregar más números.");
        }
    }

    public int[] getNumeros() {
        return Arrays.copyOf(numeros, cantidad);
    }

    public int getCantidad() {
        return cantidad;
    }
}