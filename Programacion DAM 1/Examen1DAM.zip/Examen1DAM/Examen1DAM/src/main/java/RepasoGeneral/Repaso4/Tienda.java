package RepasoGeneral.Repaso4;

class Tienda {
    // Método para calcular el precio total de los productos
    public static double calcularPrecioTotal(Producto[] productos) {
        double precioTotal = 0;
        for (Producto producto : productos) {
            precioTotal += producto.getPrecio();
        }
        return precioTotal;
    }

    // Método para encontrar el producto más caro
    public static Producto encontrarProductoMasCaro(Producto[] productos) {
        Producto productoMasCaro = null;
        double precioMasAlto = Double.MIN_VALUE;
        for (Producto producto : productos) {
            if (producto.getPrecio() > precioMasAlto) {
                precioMasAlto = producto.getPrecio();
                productoMasCaro = producto;
            }
        }
        return productoMasCaro;
    }
}